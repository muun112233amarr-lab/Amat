<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Create Account — ᗴᒪᗰOᗪᗰᗴᑎ AI</title>
<meta content="Create your ᗴᒪᗰOᗪᗰᗴᑎ AI account and start building with AI" name="description"/>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link crossorigin="anonymous" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" referrerpolicy="no-referrer" rel="stylesheet"/>
<link href="#assets/common.css?v=1775755466" rel="stylesheet"/>
<link href="#assets/auth.css?v=1775755466" rel="stylesheet"/>
</head>
<body class="auth-body">
<canvas id="meshCanvas"></canvas>
<div class="auth-split">
<!-- Left decorative panel -->
<div class="auth-panel-left">
<div class="orb orb-1"></div>
<div class="orb orb-2"></div>
<div class="brand-mark">
<div class="brand-icon"><i class="fa-solid fa-bolt"></i></div>
<span class="brand-name">ᗴᒪᗰOᗪᗰᗴᑎ AI</span>
</div>
<div>
<div class="tagline">Your AI-powered <span>dev partner</span></div>
<p class="sub-tagline">Join thousands of developers building faster with next-generation AI assistance.</p>
</div>
<div class="auth-feature-list">
<div class="auth-feature-item">
<div class="feat-icon"><i class="fa-solid fa-rocket"></i></div>
<span>Start building in seconds</span>
</div>
<div class="auth-feature-item">
<div class="feat-icon"><i class="fa-solid fa-shield-halved"></i></div>
<span>Bring your own API key</span>
</div>
<div class="auth-feature-item">
<div class="feat-icon"><i class="fa-solid fa-arrows-spin"></i></div>
<span>Persistent AI memory per project</span>
</div>
<div class="auth-feature-item">
<div class="feat-icon"><i class="fa-solid fa-terminal"></i></div>
<span>Full filesystem integration</span>
</div>
</div>
</div>
<!-- Right auth panel -->
<div class="auth-panel-right">
<div class="auth-container">
<div class="auth-logo">
<div class="auth-logo-wrap"><i class="fa-solid fa-user-plus"></i></div>
</div>
<h2>Create Account - ᗴᒪᗰOᗪᗰᗴᑎ</h2>
<p class="auth-subtitle">Start building amazing apps with AI</p>
<form autocomplete="on" method="POST">
<div class="auth-fields">
<div class="auth-input-group">
<span class="auth-input-icon"><i class="fa-solid fa-at"></i></span>
<input autocomplete="username" autofocus="" minlength="3" name="username" placeholder="Choose a username" required="" type="text" value=""/>

</div>
<div class="auth-input-group">
<span class="auth-input-icon"><i class="fa-solid fa-envelope"></i></span>
<input type="email" name="email" placeholder="Email address" required>
</div>
<div class="auth-input-group auth-pass-wrapper">

<span class="auth-input-icon"><i class="fa-solid fa-lock"></i></span>
<input autocomplete="new-password" id="regPassword" minlength="6" name="password" placeholder="Create a password" required="" type="password"/>
<button class="auth-pass-toggle" onclick="togglePass('regPassword', this)" tabindex="-1" type="button">
<i class="fa-solid fa-eye"></i>
</button>
</div>
<div class="auth-input-group auth-pass-wrapper">
<span class="auth-input-icon"><i class="fa-solid fa-lock-open"></i></span>
<input autocomplete="new-password" id="regConfirm" minlength="6" name="confirm_password" placeholder="Confirm password" required="" type="password"/>
<button class="auth-pass-toggle" onclick="togglePass('regConfirm', this)" tabindex="-1" type="button">
<i class="fa-solid fa-eye"></i>
</button>
</div>
</div>
<!-- Password strength indicator -->
<div id="pwStrength" style="margin-top:8px; display:none; gap:4px; display:flex;">
<div class="pw-bar" id="bar1"></div>
<div class="pw-bar" id="bar2"></div>
<div class="pw-bar" id="bar3"></div>
<div class="pw-bar" id="bar4"></div>
</div>
<button style="margin-top:18px;" type="submit">
<i class="fa-solid fa-user-plus"></i>  Create Account
                    </button>
</form>
<div class="auth-footer">
<p>Already have an account? <a href="#log.php">Sign in</a></p>
</div>
</div>
</div>
</div>
<style>
        .pw-bar {
            flex: 1;
            height: 3px;
            border-radius: 2px;
            background: var(--border-default);
            transition: background 0.3s ease;
        }
        .pw-bar.weak   { background: var(--error); }
        .pw-bar.medium { background: var(--warning); }
        .pw-bar.strong { background: var(--success); }
    </style>
<script>
        function togglePass(id, btn) {
            const inp = document.getElementById(id);
            const icon = btn.querySelector('i');
            if (inp.type === 'password') {
                inp.type = 'text';
                icon.className = 'fa-solid fa-eye-slash';
            } else {
                inp.type = 'password';
                icon.className = 'fa-solid fa-eye';
            }
        }

        // Password strength indicator
        document.getElementById('regPassword').addEventListener('input', function () {
            const val = this.value;
            const bars = [document.getElementById('bar1'), document.getElementById('bar2'), document.getElementById('bar3'), document.getElementById('bar4')];
            const strength = [/[a-z]/, /[A-Z]/, /[0-9]/, /[^a-zA-Z0-9]/].filter(r => r.test(val)).length + (val.length >= 8 ? 1 : 0);

            bars.forEach((b, i) => {
                b.classList.remove('weak', 'medium', 'strong');
                if (strength >= 5 && i < 4) b.classList.add('strong');
                else if (strength >= 3 && i < 3) b.classList.add('medium');
                else if (strength >= 1 && i === 0) b.classList.add('weak');
            });

            document.getElementById('pwStrength').style.display = val.length > 0 ? 'flex' : 'none';
        });

        // Auth page mesh background
        (function () {
            const canvas = document.getElementById('meshCanvas');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            let w, h;
            const particles = [];

            function resize() {
                w = canvas.width = window.innerWidth;
                h = canvas.height = window.innerHeight;
            }
            resize();
            window.addEventListener('resize', resize);

            for (let i = 0; i < 45; i++) {
                particles.push({
                    x: Math.random() * w, y: Math.random() * h,
                    vx: (Math.random() - 0.5) * 0.28, vy: (Math.random() - 0.5) * 0.28,
                    r: Math.random() * 2 + 0.4, opacity: Math.random() * 0.35 + 0.08
                });
            }

            function draw() {
                ctx.clearRect(0, 0, w, h);
                for (let i = 0; i < particles.length; i++) {
                    for (let j = i + 1; j < particles.length; j++) {
                        const dx = particles[i].x - particles[j].x;
                        const dy = particles[i].y - particles[j].y;
                        const dist = Math.sqrt(dx * dx + dy * dy);
                        if (dist < 140) {
                            ctx.beginPath();
                            ctx.moveTo(particles[i].x, particles[i].y);
                            ctx.lineTo(particles[j].x, particles[j].y);
                            ctx.strokeStyle = `rgba(99, 102, 241, ${(1 - dist / 140) * 0.09})`;
                            ctx.lineWidth = 0.5;
                            ctx.stroke();
                        }
                    }
                }
                particles.forEach(p => {
                    p.x += p.vx; p.y += p.vy;
                    if (p.x < 0 || p.x > w) p.vx *= -1;
                    if (p.y < 0 || p.y > h) p.vy *= -1;
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                    ctx.fillStyle = `rgba(99, 102, 241, ${p.opacity})`;
                    ctx.fill();
                });
                requestAnimationFrame(draw);
            }
            draw();
        })();
    </script>

<div style="position:fixed;bottom:10px;left:0;right:0;text-align:center;font-size:12px;opacity:.6">
Owned by ᗴᒪᗰOᗪᗰᗴᑎ
</div>
</body>

<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'},{'ap':'cpsh-oh'},{'server':'sxb1plzcpnl509410'},{'dcenter':'sxb1'},{'cp_id':'10844478'},{'cp_cl':'8'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src="https://img1.wsimg.com/traffic-assets/js/tccl.min.js"></script></html>